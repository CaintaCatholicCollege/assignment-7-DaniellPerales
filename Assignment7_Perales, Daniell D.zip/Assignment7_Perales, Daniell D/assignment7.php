<?php
	$checkage = 100;

	if ($checkage < "10" ) {
	  echo "You are too young!";
	} 

	elseif ($checkage > "10" && $checkage <= "18") {
	  echo "Have a good day!";
	} 

	elseif ($checkage > "18" && $checkage <= "30") {
	  echo "Young Lad!";
	} 

	elseif ($checkage > "30" && $checkage <= "60") {
	  echo "Adulthood!";
	} 

	else  {
	  echo "You're old";
	}
	?>

=================================================

  <?php

  for ($count = 1; $count <= 100; $count++){

  $squared = $count * $count;

  print("$count * $count = $squared <br>");
  
  }
  ?>

===========================================

	<?php
	$readytoVote = 18;

	if ($readytoVote < "18" ) {
	  echo "You are too young to VOTE";
	} 

	else {
	  echo "You're legal to VOTE";
	}
	?>

===========================================

    <?php
    $ceu = array( "Italy"=>"Rome", "Luxembourg"=>"Luxembourg",
    "Belgium"=> "Brussels", "Denmark"=>"Copenhagen",
    "Finland"=>"Helsinki", "France" => "Paris",
    "Slovakia"=>"Bratislava", "Slovenia"=>"Ljubljana",
    "Germany" => "Berlin", "Greece" => "Athens",
    "Ireland"=>"Dublin", "Netherlands"=>"Amsterdam",
    "Portugal"=>"Lisbon", "Spain"=>"Madrid",
    "Sweden"=>"Stockholm", "United Kingdom"=>"London",
    "Cyprus"=>"Nicosia", "Lithuania"=>"Vilnius",
    "Czech Republic"=>"Prague", "Estonia"=>"Tallin",
    "Hungary"=>"Budapest", "Latvia"=>"Riga","Malta"=>"Valetta",
    "Austria" => "Vienna", "Poland"=>"Warsaw") ;
    
        asort($ceu) ;
         foreach($ceu as $country => $capital)
        {
          echo ("The capital of $country is $capital <br>") ;
    }
    ?>

====================================================

    <?php 

     $x=8; 

     echo "Value is now " . $x . "<br>";
     $x += 2;
     echo "Value is now " . $x . "<br>";
     $x -= 4;
     echo "Value is now " . $x . "<br>";
     $x *= 5;
     echo "Value is now " . $x . "<br>";
     $x /= 3;
     echo "Value is now " . $x  . "<br>";
     $x = ++$x;
     echo "Value is now " . $x  . "<br>";
     $x = --$x;
     echo "Value is now " . $x  . "<br>";


     ?>